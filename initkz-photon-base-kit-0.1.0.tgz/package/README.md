# @initkz/website-builder-base-kit

Base installable kit for the Website Builder foundation.

It ships a reusable starter block family, themes, profile presets and server-safe documents.

Package shape:

- `src/blocks` — block definitions and renderers
- `src/themes` — theme and variant mapping exports
- `src/profile-presets` — starter profile preset helpers
- `src/documents.ts` — server-safe starter documents and template factories
- `src/module.tsx` — installable kit assembly

The package exists to prove the target architecture:

- core builder logic lives in `@initkz/website-builder`
- framework integration lives in `@initkz/website-builder-nextjs`
- reusable product content ships as installable kits instead of app-local code
